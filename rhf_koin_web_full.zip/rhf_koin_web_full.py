
from flask import Flask, render_template, request, redirect, url_for, session
import random

app = Flask(__name__)
app.secret_key = 'super_secret'

USERNAME = 'admin'
PASSWORD = 'rhf12345'

cryptos = [
    {"name": "RHF Koin", "symbol": "RHF", "price": 1000.0},
]
for i in range(1, 51):
    cryptos.append({
        "name": f"Crypto {i}",
        "symbol": f"C{i}",
        "price": round(random.uniform(100, 1000), 2),
    })

@app.route("/")
def home():
    return render_template("index.html", cryptos=cryptos)

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if request.form["username"] == USERNAME and request.form["password"] == PASSWORD:
            session["admin"] = True
            return redirect(url_for("dashboard"))
    return render_template("admin_login.html")

@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():
    if not session.get("admin"):
        return redirect(url_for("login"))
    if request.method == "POST":
        idx = int(request.form["index"])
        new_price = float(request.form["price"])
        cryptos[idx]["price"] = new_price
    return render_template("dashboard.html", cryptos=cryptos)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
